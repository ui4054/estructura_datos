package model.vo;

public class LideresProyectosEmblematicos {
    private Integer idLider;
    private Integer idProyecto;
    private Integer idTipo;

    public LideresProyectosEmblematicos() {
    }

    public Integer getIDLider() {
        return idLider;
    }

    public void setIDLider(Integer idLider) {
        this.idLider = idLider;
    }

    public Integer getIDProyecto() {
        return idProyecto;
    }

    public void setIDProyecto(Integer idProyecto) {
        this.idProyecto = idProyecto;
    }

    public Integer getIDTipo() {
        return idTipo;
    }

    public void setIDTipo(Integer idTipo) {
        this.idTipo = idTipo;
    }
}
