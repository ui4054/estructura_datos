package co.edu.utp.misiontic2022.c2.controlador;

public enum Operacion {
    SUMA, RESTA, MULTIPLICACION, DIVISION, MODULO
}
