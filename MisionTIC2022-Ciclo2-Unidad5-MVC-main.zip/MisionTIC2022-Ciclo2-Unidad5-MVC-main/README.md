# MisionTIC2022-Ciclo2-Unidad5-MVC

Ejercicio para explicar la aplicacion del patron MVC en una calculadora en consola o con Interfaz Gráfica en Swing
