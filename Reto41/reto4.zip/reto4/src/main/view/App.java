package main.view;

import main.util.JDBCUtilities;

import main.view.VistaRequerimientosReto4;

public class App {
    public static void main(String[] args) throws Exception {

        // casos de prueba

        // Requerimiento 1 reto 3
        VistaRequerimientosReto4.requerimiento1();
        System.out.println();

        // Requerimiento3 - Reto 4
        VistaRequerimientosReto4.requerimiento3();
        System.out.println();

        // Requerimiento4 - Reto3
        VistaRequerimientosReto4.requerimiento4();
        System.out.println();
    }
}
